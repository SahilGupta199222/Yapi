package com.yapi.common

object WebAPIKeys {
    const val BASEURL:String="http://192.168.1.87:3000/auth/"
}