package com.yapi.common

object Constants {
 const val BASEURL:String="http://www.google.com"
}