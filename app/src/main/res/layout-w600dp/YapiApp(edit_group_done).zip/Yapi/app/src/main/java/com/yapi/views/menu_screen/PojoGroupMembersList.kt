package com.yapi.views.menu_screen

data class PojoGroupMembersList(val name:String, val unSeenMsgCount:Int, var selected:Boolean=false)
